package com.example.jsonparse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface RequestInterface {
    //get request ko lagi api call name dim
    @GET("cars_list.json")
    Call<List <CarModelClass>> getCarJson();
}
