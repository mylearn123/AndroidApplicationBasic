package com.example.jsonparse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rv;
    ArrayList<CarModelClass> carModelClasses = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = findViewById(R.id.rv_id);
        LinearLayoutManager lilama = new LinearLayoutManager(this);
        rv.setLayoutManager(lilama);
        getCarResponse();
    }

    private void getCarResponse() {
        //now lets make connections to json file sanga using retrofit ko object
        Retrofit haudeRetrofit = new Retrofit.Builder().baseUrl("https://navneet7k.github.io/").addConverterFactory(GsonConverterFactory.create()).build();

        //request interface
        RequestInterface requestInterface = haudeRetrofit.create(RequestInterface.class);
        //aba we call method inside interface
        Call<List<CarModelClass>> myCall = requestInterface.getCarJson();
        myCall.enqueue(new Callback<List<CarModelClass>>() {
            @Override
            public void onResponse(Call<List<CarModelClass>> call, Response<List<CarModelClass>> response) {

                carModelClasses = new ArrayList<>(response.body());
                CarsAdapter carsAdapter = new CarsAdapter(carModelClasses, MainActivity.this);
                rv.setAdapter(carsAdapter);
                Toast.makeText(MainActivity.this,"Successful Connection",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<List<CarModelClass>> call, Throwable t) {
                Toast.makeText(MainActivity.this,"Connection Failed",Toast.LENGTH_SHORT).show();

            }
        });



    }
}
