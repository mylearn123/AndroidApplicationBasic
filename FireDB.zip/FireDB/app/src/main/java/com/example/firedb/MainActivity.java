package com.example.firedb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText singer_name;
    Spinner spin_genre;
    ListView lv;

    DatabaseReference dbRef;
    List<Singer> listSinger;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        singer_name = findViewById(R.id.edit_singer_id);
        spin_genre = findViewById(R.id.spin_genre_id);
        lv = findViewById(R.id.lv_id);

        dbRef = FirebaseDatabase.getInstance().getReference("Singer");
        listSinger = new ArrayList<>();

    }

    //onStart function
    @Override
    protected void onStart(){
        super.onStart();

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listSinger.clear();

                for(DataSnapshot singerSnapshot : dataSnapshot.getChildren()){
                    Singer obj = singerSnapshot.getValue(Singer.class);
                    listSinger.add(obj);
                }
                SingerAdapter adapter = new SingerAdapter(MainActivity.this,listSinger);
                lv.setAdapter(adapter);


                Toast.makeText(MainActivity.this, "Firebase Connected", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(MainActivity.this, "Firebase Connection Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }



    public void add_Singer(View view) {
        //add singer button click garda k action garnai ho ya lekhnai
        String singerName = singer_name.getText().toString();
        String singerGenre = spin_genre.getSelectedItem().toString();

        if(TextUtils.isEmpty(singerName)){
            Toast.makeText(this, "Singer Name is Empty", Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            //firebase database ma store garnai
            String id = dbRef.push().getKey();
            Singer singerObj = new Singer(id,singerName,singerGenre);
            dbRef.child(id).setValue(singerObj);
            Toast.makeText(this, "Singer added to Firebase Database", Toast.LENGTH_SHORT).show();
        }

    }
}
