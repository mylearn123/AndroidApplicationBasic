package com.example.firedb;

public class Singer {     // yo chai model class
    String singerID;
    String singerName;
    String singerGenre;

    public Singer() {
        //default constructor
        //formality ko lagi
    }

    //Constructor as setter
    public Singer(String singerID, String singerName, String singerGenre) {
        this.singerID = singerID;
        this.singerName = singerName;
        this.singerGenre = singerGenre;
    }

    //getters

    public String getSingerID() {
        return singerID;
    }

    public String getSingerName() {
        return singerName;
    }

    public String getSingerGenre() {
        return singerGenre;
    }
}
