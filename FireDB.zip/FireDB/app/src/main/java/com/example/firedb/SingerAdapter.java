package com.example.firedb;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class SingerAdapter extends ArrayAdapter<Singer> {

    private Activity context;
    private List<Singer> singerList;

    public SingerAdapter( Activity context, List<Singer> singerList) {
        super(context, R.layout.item_layout,singerList);
        this.context = context;
        this.singerList = singerList;
    }

    @NonNull
    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.item_layout,null,true);

        TextView tvName = view.findViewById(R.id.textName);
        TextView tvGenre = view.findViewById(R.id.textGenre);

        Singer singerObj = singerList.get(position);
        tvName.setText(singerObj.getSingerName());
        tvGenre.setText(singerObj.getSingerGenre());


        return view;
    }
}
