package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText signup_email , signup_pass, signup_confirm_pass;
    EditText login_email , login_pass;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signup_email = findViewById(R.id.signup_email_id);
        signup_pass = findViewById(R.id.signup_pass_id);
        signup_confirm_pass = findViewById(R.id.signup_confirmpass_id);

        mAuth = FirebaseAuth.getInstance();


    }

    public void signUp(View view) {
        //signup function click garda yo function call hunxa
        String email = signup_email.getText().toString().trim();
        String pass = signup_pass.getText().toString().trim();
        String confirm_pass = signup_confirm_pass.getText().toString().trim();

        if (TextUtils.isEmpty(email)){
            Toast.makeText(this, "Email Empty", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(pass)){
            Toast.makeText(this, "Password Empty", Toast.LENGTH_SHORT).show();
        }
        else if (TextUtils.isEmpty(confirm_pass)){
            Toast.makeText(this, "Confirm Password Empty", Toast.LENGTH_SHORT).show();
        }
        else if (pass.length()<6){
            Toast.makeText(this, "Password too short", Toast.LENGTH_SHORT).show();
        }
        else if (pass.equals(confirm_pass)){
            createAccount(email,pass);
        }
        else{
            Toast.makeText(this, "Password do not match", Toast.LENGTH_SHORT).show();
        }
    }

    private void createAccount(String email, String pass) {
        //firebase ko signup garnai code rakhnai yeta
        mAuth.createUserWithEmailAndPassword(email, pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            //sign up success vauo vanai yo if condition execute hunxa
                            Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();

                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        }

                        // ...
                    }
                });
    }}




